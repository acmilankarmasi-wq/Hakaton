import React from 'react';
import { Student, LanguageCode } from '../types';
import { translations } from '../utils/translations';
import { Calculator, ArrowRight, Wallet, Percent, Clock } from 'lucide-react';

interface DailyAnalysisProps {
  students: Student[];
  interestRate: number;
  setInterestRate: (rate: number) => void;
  loanTermYears: number;
  setLoanTermYears: (years: number) => void;
  language: LanguageCode;
}

export const DailyAnalysis: React.FC<DailyAnalysisProps> = ({ 
  students,
  interestRate,
  setInterestRate,
  loanTermYears,
  setLoanTermYears,
  language
}) => {
  const t = translations[language];
  
  // Helper to calculate monthly loan payment (Amortization Formula)
  const calculateMonthlyPayment = (principal: number, annualRate: number, years: number): number => {
    if (principal <= 0) return 0;
    if (annualRate <= 0) return principal / (years * 12);
    
    const monthlyRate = annualRate / 100 / 12;
    const numberOfPayments = years * 12;
    
    return (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / 
           (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Configuration Panel */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 shadow-lg">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Calculator className="text-blue-400" />
              {t.dailySimulator}
            </h2>
            <p className="text-white/60 text-sm mt-1">
              {t.dailyDesc}
            </p>
          </div>

          <div className="flex flex-wrap gap-4 bg-black/20 p-4 rounded-xl border border-white/5">
            <div className="space-y-1">
              <label className="text-xs font-medium text-white/70 flex items-center gap-1">
                <Percent size={12} /> {t.interestRate}
              </label>
              <input 
                type="number" 
                min="0" 
                max="20" 
                step="0.1"
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="bg-white/10 border border-white/20 rounded-lg px-3 py-1.5 text-white w-32 focus:outline-none focus:border-blue-400"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-white/70 flex items-center gap-1">
                <Clock size={12} /> {t.loanTerm}
              </label>
              <input 
                type="number" 
                min="1" 
                max="30" 
                value={loanTermYears}
                onChange={(e) => setLoanTermYears(Number(e.target.value))}
                className="bg-white/10 border border-white/20 rounded-lg px-3 py-1.5 text-white w-32 focus:outline-none focus:border-blue-400"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Grid of Calculations */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {students.map(student => {
          const monthlyLoanPayment = calculateMonthlyPayment(student.totalLoan, interestRate, loanTermYears);
          
          // Daily Calculations (assuming 30 days/month for simplicity)
          const dailyIncome = student.monthlySalary / 30;
          const dailyLoss = monthlyLoanPayment / 30;
          const dailyRemaining = dailyIncome - dailyLoss;
          
          const percentRemaining = (dailyRemaining / dailyIncome) * 100;
          const isDanger = percentRemaining < 30;

          return (
            <div key={student.id} className="group bg-white/5 hover:bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10 transition-all hover:border-white/30 hover:shadow-xl relative overflow-hidden">
              {/* Header */}
              <div className="flex justify-between items-start mb-4 relative z-10">
                <div>
                  <h3 className="text-lg font-bold text-white">{student.name}</h3>
                  <span className="text-xs text-white/50 bg-white/10 px-2 py-0.5 rounded-full">{student.major}</span>
                </div>
                {isDanger && (
                  <span className="bg-red-500/20 text-red-200 text-xs px-2 py-1 rounded border border-red-500/30">
                    {t.highDebt}
                  </span>
                )}
              </div>

              {/* Visualization Bar */}
              <div className="w-full h-3 bg-white/10 rounded-full mb-6 relative overflow-hidden">
                <div 
                  className={`h-full absolute left-0 top-0 rounded-full transition-all duration-500 ${isDanger ? 'bg-red-400' : 'bg-green-400'}`}
                  style={{ width: `${Math.max(0, percentRemaining)}%` }}
                />
              </div>

              {/* Stats Grid */}
              <div className="space-y-3 relative z-10">
                {/* Income */}
                <div className="flex justify-between items-center text-sm">
                  <span className="text-white/60 flex items-center gap-2">
                    <Wallet size={14} /> {t.dailyIncome}
                  </span>
                  <span className="font-mono text-green-300 font-medium">
                    +${dailyIncome.toFixed(2)}
                  </span>
                </div>

                {/* Loss */}
                <div className="flex justify-between items-center text-sm">
                  <span className="text-white/60 flex items-center gap-2">
                    <ArrowRight size={14} className="rotate-45 text-red-400" /> {t.dailyCost}
                  </span>
                  <span className="font-mono text-red-300 font-medium">
                    -${dailyLoss.toFixed(2)}
                  </span>
                </div>

                <div className="h-px bg-white/10 my-2"></div>

                {/* Remaining */}
                <div className="flex justify-between items-center bg-black/20 p-3 rounded-lg border border-white/5">
                  <span className="text-white/90 font-medium text-sm">
                    {t.willRemain}
                    <span className="block text-[10px] text-white/40 font-normal">{t.exclEssentials}</span>
                  </span>
                  <span className={`font-mono text-xl font-bold ${dailyRemaining < 0 ? 'text-red-400' : 'text-blue-300'}`}>
                    ${dailyRemaining.toFixed(2)}
                  </span>
                </div>
              </div>
              
              {/* Background Decoration */}
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-blue-500/20 transition-all"></div>
            </div>
          );
        })}

        {students.length === 0 && (
          <div className="col-span-full flex flex-col items-center justify-center py-12 text-white/40 bg-white/5 rounded-2xl border border-white/10 border-dashed">
            <Calculator size={48} className="mb-4 opacity-50" />
            <p>{t.noRecords}</p>
          </div>
        )}
      </div>
    </div>
  );
};
