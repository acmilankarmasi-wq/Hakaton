import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Student, FinancialStats, LanguageCode } from '../types';
import { translations } from '../utils/translations';
import { Users, DollarSign, TrendingUp, AlertCircle, ArrowUpRight } from 'lucide-react';

interface DashboardProps {
  students: Student[];
  language: LanguageCode;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export const Dashboard: React.FC<DashboardProps> = ({ students, language }) => {
  const t = translations[language];
  
  // Calculate stats
  const stats: FinancialStats = React.useMemo(() => {
    const totalStudents = students.length;
    if (totalStudents === 0) return { totalStudents: 0, averageSalary: 0, totalLoans: 0, averageLoan: 0, debtToIncomeRatio: 0 };

    const totalSalary = students.reduce((acc, s) => acc + s.monthlySalary, 0);
    const totalLoans = students.reduce((acc, s) => acc + s.totalLoan, 0);

    return {
      totalStudents,
      averageSalary: totalSalary / totalStudents,
      totalLoans,
      averageLoan: totalLoans / totalStudents,
      debtToIncomeRatio: (totalLoans / (totalSalary * 12 || 1)) // annualized salary
    };
  }, [students]);

  const chartData = students.map(s => ({
    name: s.name,
    Salary: s.monthlySalary,
    Loan: s.totalLoan
  }));

  const majorData = React.useMemo(() => {
    const counts: {[key: string]: number} = {};
    students.forEach(s => {
      counts[s.major] = (counts[s.major] || 0) + 1;
    });
    return Object.keys(counts).map(key => ({ name: key, value: counts[key] }));
  }, [students]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 text-white shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-white/70">{t.totalBorrowers}</h3>
            <Users className="w-5 h-5 text-blue-400" />
          </div>
          <p className="text-3xl font-bold">{stats.totalStudents}</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 text-white shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-white/70">{t.avgSalary}</h3>
            <DollarSign className="w-5 h-5 text-green-400" />
          </div>
          <p className="text-3xl font-bold">${stats.averageSalary.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 text-white shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-white/70">{t.totalOutstanding}</h3>
            <TrendingUp className="w-5 h-5 text-red-400" />
          </div>
          <p className="text-3xl font-bold">${stats.totalLoans.toLocaleString()}</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 text-white shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-white/70">{t.avgLoan}</h3>
            <AlertCircle className="w-5 h-5 text-orange-400" />
          </div>
          <p className="text-3xl font-bold">${stats.averageLoan.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
        </div>
      </div>

      {/* Peer Comparison Widget (New Feature) */}
      <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 backdrop-blur-md p-6 rounded-2xl border border-white/20 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-4">
            <div className="p-3 bg-white/10 rounded-full text-yellow-300">
                <ArrowUpRight size={24} />
            </div>
            <div>
                <h3 className="text-xl font-bold text-white">{t.peerComparison}</h3>
                <p className="text-white/70">
                    {t.peerBetter} <span className="text-green-400 font-bold">78%</span> {t.peerStudents}
                </p>
            </div>
        </div>
        <div className="hidden md:block w-1/3 bg-white/10 rounded-full h-3">
             <div className="h-full bg-gradient-to-r from-green-400 to-blue-500 rounded-full" style={{ width: '78%' }}></div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 shadow-lg min-h-[400px]">
          <h3 className="text-xl font-semibold text-white mb-6">{t.distribution}</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="name" stroke="rgba(255,255,255,0.6)" />
              <YAxis stroke="rgba(255,255,255,0.6)" />
              <Tooltip 
                contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', borderRadius: '8px', border: 'none', color: '#fff' }}
              />
              <Legend wrapperStyle={{ color: '#fff' }} />
              <Bar dataKey="Salary" name={t.monthlySalary} fill="#34d399" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Loan" name={t.totalLoan} fill="#f87171" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 shadow-lg min-h-[400px]">
          <h3 className="text-xl font-semibold text-white mb-6">{t.byMajor}</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={majorData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                fill="#8884d8"
                paddingAngle={5}
                dataKey="value"
                label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {majorData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', borderRadius: '8px', border: 'none', color: '#fff' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};