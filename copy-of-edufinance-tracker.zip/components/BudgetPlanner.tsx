import React, { useState } from 'react';
import { SavingsGoal, Expense, LanguageCode } from '../types';
import { translations } from '../utils/translations';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Plus, Trash2, Target, CreditCard, TrendingUp } from 'lucide-react';

interface BudgetPlannerProps {
  language: LanguageCode;
  expenses: Expense[];
  goals: SavingsGoal[];
  onAddExpense: (expense: Expense) => void;
  onAddGoal: (goal: SavingsGoal) => void;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export const BudgetPlanner: React.FC<BudgetPlannerProps> = ({ language, expenses, goals, onAddExpense, onAddGoal }) => {
  const t = translations[language];
  const [newExpense, setNewExpense] = useState({ category: '', amount: '', name: '' });
  const [newGoal, setNewGoal] = useState({ title: '', target: '', current: '' });

  const handleAddExpense = () => {
    if (newExpense.category && newExpense.amount) {
      onAddExpense({
        id: crypto.randomUUID(),
        category: newExpense.category,
        amount: Number(newExpense.amount),
        name: newExpense.name || newExpense.category
      });
      setNewExpense({ category: '', amount: '', name: '' });
    }
  };

  const handleAddGoal = () => {
    if (newGoal.title && newGoal.target) {
      onAddGoal({
        id: crypto.randomUUID(),
        title: newGoal.title,
        targetAmount: Number(newGoal.target),
        currentAmount: Number(newGoal.current) || 0,
        color: COLORS[goals.length % COLORS.length]
      });
      setNewGoal({ title: '', target: '', current: '' });
    }
  };

  // Chart Data
  const expenseData = expenses.map((e, index) => ({
    name: e.category,
    value: e.amount
  }));

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Top Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Expenses Section */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <CreditCard className="text-red-400" />
              {t.expenses}
            </h2>
          </div>

          <div className="flex flex-col lg:flex-row gap-6">
            <div className="flex-1 space-y-4">
              <div className="space-y-2">
                <input placeholder={t.category} value={newExpense.category} onChange={e => setNewExpense({...newExpense, category: e.target.value})} className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-white text-sm" />
                <input type="number" placeholder={t.amount} value={newExpense.amount} onChange={e => setNewExpense({...newExpense, amount: e.target.value})} className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-white text-sm" />
                <button onClick={handleAddExpense} className="w-full bg-red-500 hover:bg-red-400 text-white rounded-lg py-2 text-sm font-medium transition-colors">
                  {t.addExpense}
                </button>
              </div>
              
              <div className="max-h-[200px] overflow-y-auto space-y-2 pr-2">
                {expenses.map(exp => (
                    <div key={exp.id} className="flex justify-between items-center bg-white/5 p-2 rounded text-sm text-white">
                        <span>{exp.category}</span>
                        <span className="font-mono">${exp.amount}</span>
                    </div>
                ))}
              </div>
            </div>
            
            <div className="flex-1 min-h-[200px]">
                {expenses.length > 0 ? (
                    <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                        <Pie data={expenseData} innerRadius={40} outerRadius={60} fill="#8884d8" paddingAngle={5} dataKey="value">
                        {expenseData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                        </Pie>
                        <Tooltip contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: 'none', color: '#fff' }} />
                    </PieChart>
                    </ResponsiveContainer>
                ) : (
                    <div className="h-full flex items-center justify-center text-white/30 text-xs italic">No expenses added</div>
                )}
            </div>
          </div>
        </div>

        {/* Goals Section */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Target className="text-green-400" />
                {t.savingsGoals}
                </h2>
            </div>

            <div className="space-y-4">
                <div className="flex gap-2">
                    <input placeholder="Goal Title" value={newGoal.title} onChange={e => setNewGoal({...newGoal, title: e.target.value})} className="flex-1 bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-white text-sm" />
                    <input type="number" placeholder="Target $" value={newGoal.target} onChange={e => setNewGoal({...newGoal, target: e.target.value})} className="w-24 bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-white text-sm" />
                </div>
                <button onClick={handleAddGoal} className="w-full bg-green-600 hover:bg-green-500 text-white rounded-lg py-2 text-sm font-medium transition-colors">
                  {t.addGoal}
                </button>
            </div>

            <div className="mt-6 space-y-4">
                {goals.map(goal => {
                    const progress = Math.min(100, (goal.currentAmount / goal.targetAmount) * 100);
                    return (
                        <div key={goal.id} className="bg-black/20 p-4 rounded-xl border border-white/5">
                            <div className="flex justify-between items-center mb-2">
                                <span className="text-white font-medium">{goal.title}</span>
                                <span className="text-xs text-white/60">${goal.currentAmount} / ${goal.targetAmount}</span>
                            </div>
                            <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                                <div 
                                    className="h-full bg-green-500 rounded-full transition-all duration-1000" 
                                    style={{ width: `${progress}%`, backgroundColor: goal.color }}
                                />
                            </div>
                        </div>
                    );
                })}
                 {goals.length === 0 && (
                    <div className="text-center text-white/30 text-xs italic py-8">Set a goal to start saving!</div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};