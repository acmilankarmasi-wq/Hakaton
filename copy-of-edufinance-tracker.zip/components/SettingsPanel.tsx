import React, { useState, useEffect, useMemo } from 'react';
import { Settings, User, Globe, MessageSquare, Send, X, Clock, TrendingUp, TrendingDown, History } from 'lucide-react';
import { Student, ChatMessage, LanguageCode } from '../types';
import { getSupportResponse } from '../services/geminiService';
import { translations, SUPPORTED_LANGUAGES } from '../utils/translations';
import ReactMarkdown from 'react-markdown';

interface SettingsPanelProps {
  students: Student[];
  interestRate: number;
  loanTermYears: number;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ students, interestRate, loanTermYears, language, setLanguage }) => {
  const t = translations[language];
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'contact'>('profile');
  const [installDate, setInstallDate] = useState<number>(Date.now());
  
  // Chat State
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // Initialize Chat greeting when first load
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{ role: 'model', text: 'Hello! I am your AI assistant. How can I help you today?', timestamp: Date.now() }]);
    }
  }, []);

  // When language changes, add a new greeting in that language
  useEffect(() => {
    const greetings: Record<LanguageCode, string> = {
      'English': "How can I help you?",
      'Mandarin Chinese': "我能为您做些什么？",
      'Hindi': "मैं आपकी कैसे मदद कर सकता हूँ?",
      'Spanish': "¿En qué puedo ayudarte?",
      'Arabic': "كيف يمكنني مساعدتك؟",
      'French': "Comment puis-je vous aider ?",
      'Bengali': "আমি আপনাকে কিভাবে সাহায্য করতে পারি?",
      'Portuguese': "Como posso ajudar você?",
      'Russian': "Чем могу помочь?",
      'Indonesian': "Apa yang bisa saya bantu?",
      'Azerbaijani': "Sizə necə kömək edə bilərəm?",
      'Turkish': "Size nasıl yardımcı olabilirim?"
    };

    if (messages.length > 0) {
        setMessages(prev => [...prev, { role: 'model', text: greetings[language] || "How can I help you?", timestamp: Date.now() }]);
    }
  }, [language]);

  // Initialize Install Date
  useEffect(() => {
    const storedDate = localStorage.getItem('eduFinanceInstallDate');
    if (storedDate) {
      setInstallDate(parseInt(storedDate, 10));
    } else {
      const now = Date.now();
      localStorage.setItem('eduFinanceInstallDate', now.toString());
      setInstallDate(now);
    }
  }, []);

  // Calculate Cumulative Stats
  const stats = useMemo(() => {
    const daysSinceInstall = Math.max(1, Math.floor((Date.now() - installDate) / (1000 * 60 * 60 * 24)));
    
    // Calculate total daily values for current student set
    let totalDailySalary = 0;
    let totalDailyLoanCost = 0;

    const calculateMonthlyPayment = (principal: number, annualRate: number, years: number): number => {
      if (principal <= 0) return 0;
      if (annualRate <= 0) return principal / (years * 12);
      const monthlyRate = annualRate / 100 / 12;
      const numberOfPayments = years * 12;
      return (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / 
             (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
    };

    students.forEach(s => {
      totalDailySalary += s.monthlySalary / 30;
      totalDailyLoanCost += calculateMonthlyPayment(s.totalLoan, interestRate, loanTermYears) / 30;
    });

    return {
      daysSinceInstall,
      totalEarned: totalDailySalary * daysSinceInstall,
      totalLost: totalDailyLoanCost * daysSinceInstall
    };
  }, [students, installDate, interestRate, loanTermYears]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const newMessage: ChatMessage = { role: 'user', text: inputMessage, timestamp: Date.now() };
    setMessages(prev => [...prev, newMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Context for AI: Summary of first student (assuming user is the first/primary profile or aggregate)
    // For simplicity, we send an aggregate or the first student's profile to represent "My Data"
    const context = students.length > 0 
      ? `User Profile: Salary $${students[0].monthlySalary}, Loan $${students[0].totalLoan}. Major: ${students[0].major}.`
      : "User Profile: No data yet.";

    const responseText = await getSupportResponse(inputMessage, language, context);
    
    setMessages(prev => [...prev, { role: 'model', text: responseText, timestamp: Date.now() }]);
    setIsTyping(false);
  };

  return (
    <>
      {/* Trigger Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 left-6 z-50 p-4 rounded-full shadow-2xl transition-all duration-300 hover:scale-110 ${isOpen ? 'bg-red-500 rotate-90' : 'bg-slate-800 border border-white/20'}`}
      >
        {isOpen ? <X className="text-white" /> : <Settings className="text-white animate-spin-slow" />}
      </button>

      {/* Panel */}
      {isOpen && (
        <div className="fixed bottom-24 left-6 w-[350px] md:w-[400px] z-50 bg-[#1a1f2e]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-slideUp flex flex-col max-h-[70vh]">
          {/* Header */}
          <div className="p-4 bg-white/5 border-b border-white/10 flex items-center justify-between">
            <h2 className="text-white font-semibold flex items-center gap-2">
              <Settings size={18} /> {t.settings}
            </h2>
            <div className="flex bg-black/20 rounded-lg p-1">
              <button 
                onClick={() => setActiveTab('profile')}
                className={`px-3 py-1 rounded text-xs font-medium transition-all ${activeTab === 'profile' ? 'bg-blue-600 text-white' : 'text-white/50 hover:text-white'}`}
              >
                {t.profile}
              </button>
              <button 
                onClick={() => setActiveTab('contact')}
                className={`px-3 py-1 rounded text-xs font-medium transition-all ${activeTab === 'contact' ? 'bg-blue-600 text-white' : 'text-white/50 hover:text-white'}`}
              >
                {t.contactUs}
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-0">
            {activeTab === 'profile' ? (
              <div className="p-6 space-y-6">
                {/* User Profile */}
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-tr from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-2xl font-bold text-white shadow-lg relative">
                    SA
                    <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-[#1a1f2e] rounded-full"></div>
                  </div>
                  <div>
                    <h3 className="text-white font-bold">Student Admin</h3>
                    <p className="text-white/50 text-xs">Premium User</p>
                    <div className="flex items-center gap-1 mt-1 text-green-400 text-xs font-medium">
                       Active
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white/40 uppercase tracking-wider">Usage History</h4>
                    
                    <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                        <div className="flex items-center gap-3 mb-2">
                            <Clock className="text-blue-400" size={16} />
                            <span className="text-white/80 text-sm">{t.activeSince}</span>
                        </div>
                        <div className="text-white font-mono text-lg font-semibold ml-7">
                            {new Date(installDate).toLocaleDateString()}
                        </div>
                        <div className="text-white/40 text-xs ml-7">
                             ({stats.daysSinceInstall} days)
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                        <div className="bg-green-500/10 rounded-xl p-3 border border-green-500/20">
                             <div className="flex items-center gap-2 mb-1 text-green-400 text-xs">
                                <TrendingUp size={14} /> {t.totalEarned}
                             </div>
                             <div className="text-white font-mono font-bold">
                                ${stats.totalEarned.toLocaleString(undefined, {maximumFractionDigits: 0})}
                             </div>
                        </div>
                        <div className="bg-red-500/10 rounded-xl p-3 border border-red-500/20">
                             <div className="flex items-center gap-2 mb-1 text-red-400 text-xs">
                                <TrendingDown size={14} /> {t.totalLost}
                             </div>
                             <div className="text-white font-mono font-bold">
                                ${stats.totalLost.toLocaleString(undefined, {maximumFractionDigits: 0})}
                             </div>
                        </div>
                    </div>
                </div>

                {/* Language */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-white/40 uppercase tracking-wider flex items-center gap-2">
                    <Globe size={14} /> {t.language}
                  </label>
                  <select 
                    value={language}
                    onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                    className="w-full bg-white/5 border border-white/10 rounded-lg p-2 text-white text-sm focus:outline-none focus:border-blue-500 cursor-pointer hover:bg-white/10 transition-colors"
                  >
                    {SUPPORTED_LANGUAGES.map((lang) => (
                      <option key={lang} value={lang} className="bg-slate-800">{lang}</option>
                    ))}
                  </select>
                </div>
              </div>
            ) : (
              <div className="flex flex-col h-[400px]">
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[85%] rounded-2xl p-3 text-sm shadow-md ${msg.role === 'user' ? 'bg-blue-600 text-white rounded-br-none' : 'bg-white/10 text-white/90 rounded-bl-none border border-white/5'}`}>
                        <ReactMarkdown>{msg.text}</ReactMarkdown>
                      </div>
                    </div>
                  ))}
                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="bg-white/10 text-white/50 rounded-2xl rounded-bl-none p-3 text-xs italic animate-pulse">
                        {t.aiTyping}
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-3 bg-white/5 border-t border-white/10">
                  <div className="flex items-center gap-2">
                    <input 
                      type="text" 
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder={t.askQuestion}
                      className="flex-1 bg-black/20 border border-white/10 rounded-full px-4 py-2 text-white text-sm focus:outline-none focus:border-blue-500 placeholder-white/30"
                    />
                    <button 
                      onClick={handleSendMessage}
                      className="p-2 bg-blue-600 rounded-full text-white hover:bg-blue-500 transition-colors shadow-lg"
                    >
                      <Send size={16} />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};