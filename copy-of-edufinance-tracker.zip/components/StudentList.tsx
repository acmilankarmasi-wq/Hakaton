import React, { useState } from 'react';
import { Student, LanguageCode } from '../types';
import { translations } from '../utils/translations';
import { Plus, Trash2, Edit2, Save, X, User, Wallet, FileText } from 'lucide-react';

interface StudentListProps {
  students: Student[];
  onAddStudent: (student: Student) => void;
  onUpdateStudent: (student: Student) => void;
  onDeleteStudent: (id: string) => void;
  language: LanguageCode;
}

export const StudentList: React.FC<StudentListProps> = ({ students, onAddStudent, onUpdateStudent, onDeleteStudent, language }) => {
  const t = translations[language];
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Form State
  const [formData, setFormData] = useState<Partial<Student>>({});

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'monthlySalary' || name === 'totalLoan' ? Number(value) : value
    }));
  };

  const startAdd = () => {
    setFormData({
      name: '',
      major: '',
      monthlySalary: 0,
      totalLoan: 0
    });
    setIsAdding(true);
    setEditingId(null);
  };

  const saveAdd = () => {
    if (formData.name && formData.major) {
      onAddStudent({
        id: crypto.randomUUID(),
        name: formData.name,
        major: formData.major,
        monthlySalary: formData.monthlySalary || 0,
        totalLoan: formData.totalLoan || 0
      });
      setIsAdding(false);
    }
  };

  const startEdit = (student: Student) => {
    setFormData(student);
    setEditingId(student.id);
    setIsAdding(false);
  };

  const saveEdit = () => {
    if (formData.id && formData.name && formData.major) {
      onUpdateStudent({
        id: formData.id,
        name: formData.name,
        major: formData.major,
        monthlySalary: formData.monthlySalary || 0,
        totalLoan: formData.totalLoan || 0
      });
      setEditingId(null);
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 shadow-xl overflow-hidden animate-fadeIn">
      {/* Header Section */}
      <div className="p-6 flex justify-between items-center border-b border-white/10 bg-black/10">
        <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/20 rounded-lg text-blue-300">
                <FileText size={24} />
            </div>
            <div>
                <h2 className="text-xl font-semibold text-white">{t.studentRecords}</h2>
                <p className="text-white/40 text-xs">Manage borrower profiles and loan details</p>
            </div>
        </div>
        
        {/* Add Loan Button - Only appears in this section */}
        {!isAdding && !editingId && (
          <button 
            onClick={startAdd}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-5 py-2.5 rounded-full transition-all shadow-lg hover:shadow-blue-500/25 font-medium text-sm transform hover:scale-105 active:scale-95"
          >
            <Plus size={18} />
            {t.addLoan}
          </button>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-white/90">
          <thead className="bg-white/5 text-white/50 uppercase text-xs font-semibold tracking-wider">
            <tr>
              <th className="px-6 py-4">{t.name}</th>
              <th className="px-6 py-4">{t.major}</th>
              <th className="px-6 py-4">{t.monthlySalary}</th>
              <th className="px-6 py-4">{t.totalLoan}</th>
              <th className="px-6 py-4 text-right">{t.actions}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {/* Add New Loan Row */}
            {isAdding && (
              <tr className="bg-blue-500/10 animate-slideDown">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-300">
                        <User size={14} />
                    </div>
                    <input autoFocus name="name" placeholder={t.name} value={formData.name || ''} onChange={handleInputChange} className="bg-black/20 border border-white/10 rounded-lg px-3 py-1.5 text-white w-full focus:outline-none focus:border-blue-400 focus:bg-black/40 transition-colors placeholder-white/20" />
                  </div>
                </td>
                <td className="px-6 py-4">
                  <input name="major" placeholder={t.major} value={formData.major || ''} onChange={handleInputChange} className="bg-black/20 border border-white/10 rounded-lg px-3 py-1.5 text-white w-full focus:outline-none focus:border-blue-400 focus:bg-black/40 transition-colors placeholder-white/20" />
                </td>
                <td className="px-6 py-4">
                  <div className="relative">
                    <span className="absolute left-3 top-1.5 text-white/30">$</span>
                    <input name="monthlySalary" type="number" placeholder="0" value={formData.monthlySalary || ''} onChange={handleInputChange} className="bg-black/20 border border-white/10 rounded-lg pl-6 pr-3 py-1.5 text-white w-full focus:outline-none focus:border-blue-400 focus:bg-black/40 transition-colors" />
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="relative">
                    <span className="absolute left-3 top-1.5 text-white/30">$</span>
                    <input name="totalLoan" type="number" placeholder="0" value={formData.totalLoan || ''} onChange={handleInputChange} className="bg-black/20 border border-white/10 rounded-lg pl-6 pr-3 py-1.5 text-white w-full focus:outline-none focus:border-blue-400 focus:bg-black/40 transition-colors" />
                  </div>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end gap-2">
                    <button onClick={saveAdd} title={t.save} className="flex items-center gap-1 px-3 py-1.5 bg-green-500 hover:bg-green-400 rounded-lg text-white text-xs font-bold transition-colors uppercase tracking-wide"><Save size={14}/> {t.save}</button>
                    <button onClick={() => setIsAdding(false)} title={t.cancel} className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors"><X size={16}/></button>
                  </div>
                </td>
              </tr>
            )}

            {/* Existing Rows */}
            {students.map((student) => (
              <tr key={student.id} className="hover:bg-white/5 transition-colors group">
                {editingId === student.id ? (
                  <>
                    <td className="px-6 py-4">
                       <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-300">
                            <User size={14} />
                        </div>
                        <input name="name" value={formData.name || ''} onChange={handleInputChange} className="bg-black/20 border border-white/10 rounded-lg px-3 py-1.5 text-white w-full focus:outline-none focus:border-blue-400 focus:bg-black/40" />
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <input name="major" value={formData.major || ''} onChange={handleInputChange} className="bg-black/20 border border-white/10 rounded-lg px-3 py-1.5 text-white w-full focus:outline-none focus:border-blue-400 focus:bg-black/40" />
                    </td>
                    <td className="px-6 py-4">
                      <input name="monthlySalary" type="number" value={formData.monthlySalary || ''} onChange={handleInputChange} className="bg-black/20 border border-white/10 rounded-lg px-3 py-1.5 text-white w-full focus:outline-none focus:border-blue-400 focus:bg-black/40" />
                    </td>
                    <td className="px-6 py-4">
                      <input name="totalLoan" type="number" value={formData.totalLoan || ''} onChange={handleInputChange} className="bg-black/20 border border-white/10 rounded-lg px-3 py-1.5 text-white w-full focus:outline-none focus:border-blue-400 focus:bg-black/40" />
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button onClick={saveEdit} title={t.save} className="p-2 bg-green-500/80 hover:bg-green-500 rounded-lg text-white"><Save size={16}/></button>
                        <button onClick={() => setEditingId(null)} title={t.cancel} className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white"><X size={16}/></button>
                      </div>
                    </td>
                  </>
                ) : (
                  <>
                    <td className="px-6 py-4 font-medium flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 group-hover:bg-blue-500/20 group-hover:text-blue-300 transition-colors">
                            <User size={14} />
                        </div>
                        {student.name}
                    </td>
                    <td className="px-6 py-4 opacity-70">{student.major}</td>
                    <td className="px-6 py-4">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-green-500/10 text-green-300 border border-green-500/20 font-mono text-sm">
                           ${student.monthlySalary.toLocaleString()}
                        </span>
                    </td>
                    <td className="px-6 py-4">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-red-500/10 text-red-300 border border-red-500/20 font-mono text-sm">
                           ${student.totalLoan.toLocaleString()}
                        </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all transform translate-x-2 group-hover:translate-x-0">
                        <button onClick={() => startEdit(student)} className="p-2 text-blue-300 hover:text-white hover:bg-blue-600 rounded-lg transition-colors"><Edit2 size={16}/></button>
                        <button onClick={() => onDeleteStudent(student.id)} className="p-2 text-red-300 hover:text-white hover:bg-red-600 rounded-lg transition-colors"><Trash2 size={16}/></button>
                      </div>
                    </td>
                  </>
                )}
              </tr>
            ))}
            
            {students.length === 0 && !isAdding && (
              <tr>
                <td colSpan={5} className="px-6 py-16 text-center text-white/30 italic">
                  <div className="flex flex-col items-center gap-3">
                    <Wallet size={32} className="opacity-50" />
                    <p>{t.noRecords}</p>
                    <button onClick={startAdd} className="text-blue-400 hover:text-blue-300 underline text-sm mt-1">{t.addLoan}</button>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};