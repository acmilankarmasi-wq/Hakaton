import React from 'react';
import { translations, SUPPORTED_LANGUAGES } from '../utils/translations';
import { LanguageCode } from '../types';
import { Building2, GraduationCap, Calculator, RefreshCw, Globe, ArrowRight, UserCircle, ScanFace } from 'lucide-react';

interface LoginScreenProps {
  onLogin: () => void;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, language, setLanguage }) => {
  const t = translations[language];

  return (
    <div className="flex min-h-screen bg-white text-slate-800 font-sans">
      {/* Left Side - Image (Hidden on Mobile) */}
      <div className="hidden lg:block w-1/2 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/20 to-transparent z-10"></div>
        <img 
          src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?q=80&w=2000&auto=format&fit=crop" 
          alt="Students Graduating" 
          className="w-full h-full object-cover"
        />
        {/* Quote/Overlay Text */}
        <div className="absolute bottom-10 left-10 z-20 text-white max-w-md p-6 bg-black/30 backdrop-blur-sm rounded-xl border border-white/10">
          <h2 className="text-2xl font-bold mb-2">Invest in your future</h2>
          <p className="text-white/80 text-sm">Empowering students with financial tools for a better tomorrow.</p>
        </div>
      </div>

      {/* Right Side - Login Content */}
      <div className="w-full lg:w-1/2 flex flex-col items-center justify-center p-8 relative">
        
        {/* Language Selector Top Right */}
        <div className="absolute top-6 right-6 flex items-center gap-2">
            <Globe size={16} className="text-slate-400" />
            <select 
            value={language}
            onChange={(e) => setLanguage(e.target.value as LanguageCode)}
            className="bg-transparent text-sm text-slate-600 font-medium focus:outline-none cursor-pointer hover:text-blue-600 transition-colors"
            >
            {SUPPORTED_LANGUAGES.map((lang) => (
                <option key={lang} value={lang}>{lang}</option>
            ))}
            </select>
        </div>

        <div className="max-w-md w-full flex flex-col items-center text-center space-y-10">
          
          {/* Logos */}
          <div className="flex items-center justify-center gap-12 w-full px-4">
             <div className="flex flex-col items-center gap-2">
                <div className="w-16 h-16 rounded-full bg-[#D4AF37]/10 flex items-center justify-center border border-[#D4AF37]/30">
                    <Building2 size={32} className="text-[#D4AF37]" />
                </div>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide max-w-[120px] leading-tight">
                    {t.ministryName}
                </span>
             </div>

             <div className="flex flex-col items-center gap-2">
                <div className="w-16 h-16 rounded-full bg-blue-600/10 flex items-center justify-center border border-blue-600/30">
                    <GraduationCap size={32} className="text-blue-600" />
                </div>
                <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wide max-w-[120px] leading-tight">
                    {t.fundName}
                </span>
             </div>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <h1 className="text-3xl font-semibold text-blue-600 tracking-tight">
                {t.portalTitle}
            </h1>
          </div>

          {/* Login Buttons */}
          <div className="w-full space-y-4">
            <button 
                onClick={onLogin}
                className="w-full group flex items-center justify-center gap-2 py-4 px-6 bg-white border border-blue-600 rounded-lg text-blue-900 text-xl font-bold hover:bg-blue-600 hover:text-white transition-all duration-300 shadow-sm hover:shadow-blue-200"
            >
                <span className="font-bold tracking-tight">digital</span>
                <div className="w-2 h-2 rounded-full bg-blue-600 group-hover:bg-white transition-colors"></div>
                <span className="font-bold tracking-tight">login</span>
            </button>

            <button 
                onClick={onLogin}
                className="w-full flex items-center justify-center gap-3 py-4 px-6 bg-white border border-slate-300 rounded-lg text-slate-600 text-lg font-medium hover:border-blue-500 hover:text-blue-600 transition-all duration-300 shadow-sm"
            >
                <div className="p-1 bg-blue-600 rounded text-white">
                    <UserCircle size={18} />
                </div>
                {t.appIdLogin}
            </button>

            {/* Biometric Login - New Trust Feature */}
            <button 
                onClick={onLogin}
                className="w-full flex items-center justify-center gap-3 py-4 px-6 bg-slate-50 border border-slate-200 rounded-lg text-slate-500 text-lg font-medium hover:bg-slate-100 hover:text-blue-600 transition-all duration-300"
            >
                <ScanFace size={20} />
                {t.biometricLogin}
            </button>
          </div>

          <div className="w-full h-px bg-slate-200 my-4"></div>

          {/* Footer Links */}
          <div className="flex flex-col sm:flex-row gap-4 w-full">
            <button className="flex-1 flex items-center justify-center gap-2 py-3 px-4 border border-blue-600/30 rounded-lg text-blue-600 font-medium hover:bg-blue-50 transition-colors text-sm">
                <Calculator size={18} />
                {t.creditCalc}
            </button>
            <button className="flex-1 flex items-center justify-center gap-2 py-3 px-4 border border-blue-600/30 rounded-lg text-blue-600 font-medium hover:bg-blue-50 transition-colors text-sm">
                <RefreshCw size={18} />
                {t.changeNum}
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};